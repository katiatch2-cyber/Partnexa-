# -*- coding: utf-8 -*-
"""
================================================================================
Partnexa — Smart Match IA · Pipeline V1 (référence)
================================================================================
Module : Matching Service (Module E du cahier des charges)
Version : 1.0
Date : Novembre 2025
Auteur : Équipe Partnexa

Objectif ----
Implémenter le moteur de recommandation explicable qui compare :
  - un BESOIN (entreprise qui cherche un partenaire/fournisseur),
  - à un ensemble d'ENTREPRISES (avec leurs services publiés),
et retourne les TOP-N meilleures correspondances avec :
  - score composite pondéré [0..100],
  - liste explicable de raisons (≥ 3),
  - badges de compatibilité.

Architecture en 4 couches (cf. cahier § 9) :
  1. Filtres déterministes          (secteur, pays, langue, statut validé)
  2. Similarité sémantique          (embeddings multilingues bge-m3)
  3. Scoring composite pondéré      (9 critères)
  4. Explicabilité XAI              (raisons lisibles + reste-à-écart)

Pré-requis d'exécution ----
  pip install sentence-transformers faiss-cpu numpy pandas scikit-learn

Pour passer en GPU (prod) :
  pip install faiss-gpu
  && vérifier disponibilité CUDA.

Notes de production ----
- Le cache Redis (warm path) n'est pas implémenté ici mais l'API est
  prévue `cache_key = hash(besoin_id + timestamp)` (TTL 24h).
- En V1.1 : ré-entraînement mensuel via LambdaMART / XGBoost Ranker sur
  la table `match_feedback`.
- En V2 : pondérations ajustables par l'utilisateur (UI Module E §9.3).
================================================================================
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any

import numpy as np

# ──────────────────────────────────────────────────────────────────────────────
# 0. Modèle d'embeddings multilingues (chargement paresseux)
# ──────────────────────────────────────────────────────────────────────────────
try:
    from sentence_transformers import SentenceTransformer
    _HAS_ST = True
except ImportError:
    _HAS_ST = False
    # En environnement de test sans sentence-transformers, on simule.
    SentenceTransformer = None  # type: ignore

try:
    import faiss  # type: ignore
    _HAS_FAISS = True
except ImportError:
    _HAS_FAISS = False
    # Fallback : numpy brut pour similarité cosinus.
    faiss = None  # type: ignore


# Constante globale — modèle open-source self-hosted (cf. cahier § 9.4)
EMBEDDING_MODEL = "BAAI/bge-m3"
EMBEDDING_DIM = 1024  # bge-m3 produit des vecteurs 1024-d


# ──────────────────────────────────────────────────────────────────────────────
# 1. Modèles de données (alignés § 7 du cahier des charges)
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class Listing:  # Besoin OU Service
    listing_id: str
    company_id: str
    type: str  # "need" | "service"
    title: str
    description: str
    sector: str
    sub_sector: str = ""
    country: str = ""
    city: str = ""
    languages: list[str] = field(default_factory=list)
    budget_min_eur: float | None = None
    budget_max_eur: float | None = None
    delivery_days: int | None = None
    quantity: float | None = None

    def to_text(self) -> str:
        """Texte canonique pour vectorisation."""
        return (
            f"{self.title}. {self.description}. "
            f"Secteur: {self.sector}. Sous-secteur: {self.sub_sector}. "
            f"Zone: {self.city} {self.country}. Langues: {','.join(self.languages)}."
        )


@dataclass
class Company:
    company_id: str
    name: str
    sector: str
    sub_sector: str = ""
    country: str = ""
    city: str = ""
    size_band: str = ""  # "1-10" | "11-50" | "51-250" | "250+"
    languages: list[str] = field(default_factory=list)
    trust_score: float = 0.0  # 0..100
    verified: bool = False
    successful_deals: int = 0

    services: list[Listing] = field(default_factory=list)

    # Alias acceptés par les tests / SDK externe : on garde une compat descendante.
    # `score_company` utilise ces valeurs si elles sont renseignées, sinon il
    # retombe sur le premier service publié.
    trust: float | None = None
    deals: int | None = None
    budget_min: float | None = None
    budget_max: float | None = None
    delivery: int | None = None


@dataclass
class MatchResult:
    company_id: str = ""
    company_name: str = ""
    score: float = 0.0  # 0..100
    reasons: list[str] = field(default_factory=list)  # raisons lisibles (FR/AR/EN)
    badges: list[str] = field(default_factory=list)  # badges visuels
    contributions: dict[str, float] = field(default_factory=dict)  # carte XAI


# ──────────────────────────────────────────────────────────────────────────────
# 2. Pondérations V1 (cahier § 4 Module E — somme = 100%)
# ──────────────────────────────────────────────────────────────────────────────

WEIGHTS: dict[str, float] = {
    "sector":        25.0,
    "semantic":      20.0,
    "location":      15.0,
    "budget":        12.0,
    "deadline":      10.0,
    "language":       8.0,
    "trust":          5.0,
    "size_match":     3.0,
    "history":        2.0,
}
assert abs(sum(WEIGHTS.values()) - 100.0) < 1e-6, "Pondérations ≠ 100 %."


# ──────────────────────────────────────────────────────────────────────────────
# 3. Couche 1 — Filtres déterministes (SQL/NoSQL en prod)
# ──────────────────────────────────────────────────────────────────────────────

def deterministic_filters(
    need: Listing,
    candidates: list[Company],
) -> list[Company]:
    """Filtre éliminatoire rapide (doit rester < 5 ms)."""
    out: list[Company] = []
    for c in candidates:
        # Conditions éliminatoires V1
        if c.country and need.country and c.country != need.country:
            # En V1 on garde un buffer de voisinage (MENA élargi) ; pour la
            # démo on est strict. Adaptera selon taxonomie "zone proche".
            continue
        if not c.verified:
            # En V1 : un compte non vérifié n'apparaît pas dans les matchs.
            continue
        # Au moins un service OU même secteur principal
        if not c.services and c.sector != need.sector:
            continue
        out.append(c)
    return out


# ──────────────────────────────────────────────────────────────────────────────
# 4. Couche 2 — Embeddings multilingues + index vectoriel (FAISS)
# ──────────────────────────────────────────────────────────────────────────────

class EmbeddingEngine:
    """Gestionnaire in-memory des embeddings. En prod : GPU + cache Redis."""

    def __init__(self, model_name: str = EMBEDDING_MODEL) -> None:
        self.model_name = model_name
        self.model = None
        if _HAS_ST:
            try:
                self.model = SentenceTransformer(model_name)
            except Exception:
                self.model = None
        self.index: Any = None
        self.vectors: np.ndarray | None = None
        self.companies: list[Company] = []

    # --------- Encodage ---------
    def embed(self, texts: list[str]) -> np.ndarray:
        if self.model is not None:
            vecs = self.model.encode(
                texts, normalize_embeddings=True, show_progress_bar=False
            )
            return np.asarray(vecs, dtype="float32")
        # Fallback déterministe pour tests sans GPU / sans réseau.
        # Hash stable -> vecteur pseudo-aléatoire reproductible.
        rng = np.random.default_rng(
            [hash(t) & 0xFFFFFFFF for t in texts]
        )
        vecs = rng.standard_normal((len(texts), EMBEDDING_DIM)).astype("float32")
        # Normalisation L2 -> cosine = dot product.
        norms = np.linalg.norm(vecs, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        return vecs / norms

    # --------- Indexation ---------
    def build_index(self, companies: list[Company]) -> None:
        self.companies = companies
        if not companies:
            self.vectors = np.zeros((0, EMBEDDING_DIM), dtype="float32")
            self.index = None
            return
        # Texte à vectoriser : concat(description + services).
        texts: list[str] = []
        for c in companies:
            agg = (
                f"{c.name} . Secteur {c.sector}/{c.sub_sector}. "
                f"Zone {c.city} {c.country}. "
                + " ".join(s.to_text() for s in c.services)
            )
            texts.append(agg)
        self.vectors = self.embed(texts)
        if _HAS_FAISS:
            # Index HNSW optionnel — ici on prend IndexFlatIP (simple).
            self.index = faiss.IndexFlatIP(EMBEDDING_DIM)
            self.index.add(self.vectors)
        else:
            self.index = None

    # --------- K-NN cosine ---------
    def top_k(self, query_text: str, k: int = 200) -> list[tuple[Company, float]]:
        if not self.companies:
            return []
        qvec = self.embed([query_text])[0]
        if self.index is not None:
            scores, idxs = self.index.search(qvec.reshape(1, -1), min(k, len(self.companies)))
            return [
                (self.companies[i], float(s))
                for s, i in zip(scores[0], idxs[0])
                if i >= 0
            ]
        # Fallback numpy
        sims = (self.vectors @ qvec).astype(float)  # type: ignore[operator]
        order = np.argsort(-sims)[:k]
        return [(self.companies[int(i)], float(sims[int(i)])) for i in order]


# ──────────────────────────────────────────────────────────────────────────────
# 5. Couche 3 — Scoring composite pondéré
# ──────────────────────────────────────────────────────────────────────────────

def _sigmoid(x: float, k: float = 1.0) -> float:
    """Normalise une valeur vers 0..1 via sigmoïde."""
    return 1.0 / (1.0 + math.exp(-k * x))


def score_company(
    need: Listing,
    company: Company,
    semantic_score: float,  # cosine 0..1
) -> tuple[float, dict[str, float], list[str], list[str]]:
    """
    Calcule le score composite d'une entreprise candidate pour un besoin donné.

    Returns
    -------
    final_score       : float  (0..100)
    contributions     : dict[str, float]  (pts par critère)
    reasons           : list[str]          (≥ 3 raisons lisibles)
    badges            : list[str]          (badges visuels UI)
    """
    contributions: dict[str, float] = {}

    # --- Secteur (25 pts) ---
    s_sector = 100.0 if company.sector == need.sector else (
        50.0 if (need.sub_sector and company.sub_sector == need.sub_sector) else 0.0
    )
    contributions["sector"] = s_sector * (WEIGHTS["sector"] / 100.0)

    # --- Sémantique (20 pts) — cosine similarity 0..1 ---
    s_sem = max(0.0, min(1.0, semantic_score)) * 100.0
    contributions["semantic"] = s_sem * (WEIGHTS["semantic"] / 100.0)

    # --- Localisation (15 pts) ---
    country_match = 100.0 if company.country == need.country else (
        60.0 if (need.country in {"MA", "TN", "DZ"} and company.country in {"MA", "TN", "DZ"}) else 0.0
    )
    city_bonus = 10.0 if (need.city and company.city == need.city) else 0.0
    s_loc = min(100.0, country_match + city_bonus)
    contributions["location"] = s_loc * (WEIGHTS["location"] / 100.0)

    # --- Budget (12 pts) — tolérance ±15 % ---
    s_budget = 0.0
    # 1) Alias top-level (Company.budget_min / budget_max)
    top_budget_max = company.budget_max
    top_budget_min = company.budget_min
    # 2) Sinon, meilleur service publié
    svc_max_list = [s.budget_max_eur for s in company.services if s.budget_max_eur is not None]

    if need.budget_min_eur is not None:
        if top_budget_max is not None:
            ratio = top_budget_max / max(need.budget_min_eur, 1e-9)
            if 0.85 <= ratio <= 1.15:
                s_budget = 100.0
            elif ratio < 0.85:
                s_budget = max(0.0, 100.0 - (0.85 - ratio) * 400.0)
            else:
                s_budget = max(0.0, 100.0 - (ratio - 1.15) * 200.0)
        elif svc_max_list:
            for v in svc_max_list:
                ratio = v / max(need.budget_min_eur, 1e-9)
                if 0.85 <= ratio <= 1.15:
                    s_budget = max(s_budget, 100.0)
                elif ratio < 0.85:
                    s_budget = max(s_budget, 100.0 - (0.85 - ratio) * 400.0)
                else:
                    s_budget = max(s_budget, 100.0 - (ratio - 1.15) * 200.0)
        elif any(s.budget_max_eur is None for s in company.services):
            s_budget = 70.0  # "sur devis"
    contributions["budget"] = s_budget * (WEIGHTS["budget"] / 100.0)

    # --- Délai (10 pts) ---
    s_deadline = 100.0  # défaut (pas d'exigence)
    top_delivery = company.delivery
    if need.delivery_days:
        if top_delivery:
            ratio = top_delivery / max(need.delivery_days, 1e-9)
            s_deadline = max(0.0, 100.0 - abs(ratio - 1.0) * 100.0)
        elif company.services:
            for svc in company.services:
                if svc.delivery_days:
                    ratio = svc.delivery_days / max(need.delivery_days, 1e-9)
                    s_deadline = max(
                        0.0,
                        100.0 - abs(ratio - 1.0) * 100.0,
                    )
                    break
    contributions["deadline"] = s_deadline * (WEIGHTS["deadline"] / 100.0)

    # --- Langues (8 pts) — au moins une commune ---
    common = set(need.languages) & set(company.languages)
    s_lang = 100.0 if common else 0.0
    contributions["language"] = s_lang * (WEIGHTS["language"] / 100.0)

    # --- Trust (5 pts) — fallback sur alias Company.trust ---
    trust_val = company.trust if company.trust is not None else company.trust_score
    s_trust = max(0.0, min(100.0, trust_val))
    contributions["trust"] = s_trust * (WEIGHTS["trust"] / 100.0)

    # --- Taille (3 pts) — heuristique : PME recherchent PME, grands <-> grands ---
    s_size = 50.0  # neutre par défaut
    if need.type == "need" and company.size_band:
        # Plus la cible est grande, plus elle "peut" livrer = bon.
        s_size = {"1-10": 30.0, "11-50": 60.0, "51-250": 90.0, "250+": 100.0}.get(
            company.size_band, 50.0
        )
    contributions["size_match"] = s_size * (WEIGHTS["size_match"] / 100.0)

    # --- Historique (2 pts) — fallback sur alias Company.deals ---
    deals_val = company.deals if company.deals is not None else company.successful_deals
    s_hist = _sigmoid((deals_val - 5) / 5.0) * 100.0
    contributions["history"] = s_hist * (WEIGHTS["history"] / 100.0)

    # --- Score final ---
    final_score = float(sum(contributions.values()))
    final_score = max(0.0, min(100.0, final_score))

    # --- Raisons lisibles (XAI) : top 3 contributions positives ---
    positive = [
        (k, v / (WEIGHTS[k] / 100.0))  # re-normalise en 0..100 par critère
        for k, v in contributions.items()
    ]
    positive.sort(key=lambda kv: -kv[1])
    reasons: list[str] = []
    trust_val_disp = company.trust if company.trust is not None else company.trust_score
    deals_val_disp = company.deals if company.deals is not None else company.successful_deals
    reason_map = {
        "sector":    "Secteur identique",
        "semantic":  "Description sémantiquement proche",
        "location":  f"Zone compatible ({company.city or company.country})",
        "budget":    "Budget aligné (±15 %)",
        "deadline":  "Délai compatible",
        "language":  f"Langue commune : {','.join(sorted(common) or ['—'])}",
        "trust":     f"Trust Score élevé ({trust_val_disp:.0f}/100)",
        "size_match":"Capacité de l'entreprise adaptée à la demande",
        "history":   f"{deals_val_disp} collaborations réussies",
    }
    # Cahier § 9.2 : ≥ 3 raisons lisibles UNIQUEMENT pour les matchs élevés
    # (score global ≥ 60). Pour les scores faibles, on liste les forces résiduelles.
    for k, score in positive:
        # seuil 60 / 100 sur la valeur normalisée du critère
        if score >= 60 and reason_map[k] not in reasons:
            reasons.append(reason_map[k])
        if len(reasons) >= 5:
            break

    # --- Badges visuels ---
    badges: list[str] = []
    if contributions["location"] / (WEIGHTS["location"] / 100.0) >= 80:
        badges.append("🚚 Logistique OK")
    if contributions["budget"] / (WEIGHTS["budget"] / 100.0) >= 80:
        badges.append("💰 Budget OK")
    trust_for_badge = company.trust if company.trust is not None else company.trust_score
    if trust_for_badge >= 80:
        badges.append("⭐ Confiance élevée")

    return final_score, contributions, reasons, badges


# ──────────────────────────────────────────────────────────────────────────────
# 6. Pipeline complet
# ──────────────────────────────────────────────────────────────────────────────

def smart_match(
    need: Listing,
    candidate_companies: list[Company],
    engine: EmbeddingEngine,
    top_n: int = 10,
) -> list[MatchResult]:
    """
    Exécute le pipeline complet (V1) :

    1. Filtres déterministes
    2. Embeddings + K-NN (top 200)
    3. Scoring composite pondéré
    4. Tri + explicabilité (top N)
    """
    # 1. Filtres
    candidates = deterministic_filters(need, candidate_companies)
    if not candidates:
        return []

    # 2. Index + K-NN
    engine.build_index(candidates)
    top_k = engine.top_k(need.to_text(), k=200)

    # 3. Scoring et explicabilité
    results: list[MatchResult] = []
    for company, sem in top_k:
        score, contribs, reasons, badges = score_company(need, company, sem)
        results.append(
            MatchResult(
                company_id=company.company_id,
                company_name=company.name,
                score=round(score, 1),
                reasons=reasons,
                badges=badges,
                contributions=contribs,
            )
        )
    # 4. Tri décroissant et top N
    results.sort(key=lambda r: -r.score)
    return results[:top_n]


# ──────────────────────────────────────────────────────────────────────────────
# 7. Boucle de feedback utilisateur (👍/👎) — stockage et futur ré-entraînement
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class MatchFeedback:
    need_id: str
    company_id: str
    signal: str  # "positive" | "negative" | "neutral"
    comment: str = ""

    def to_db_row(self) -> dict[str, Any]:
        return {
            "need_id": self.need_id,
            "company_id": self.company_id,
            "signal": self.signal,
            "comment": self.comment,
        }


# En prod : pousser dans Kafka topic "match_feedback" -> BigQuery / ClickHouse.
# Ré-entraînement LambdaMART / XGBoost Ranker tous les 30 jours (cahier § 9.3).


# ──────────────────────────────────────────────────────────────────────────────
# 8. Démo / smoke-test
# ──────────────────────────────────────────────────────────────────────────────

def _demo() -> None:  # pragma: no cover
    """Exécution simple pour validation manuelle."""
    print("=" * 72)
    print("PARTNEXA — Smart Match IA · Démo")
    print("=" * 72)

    # Besoins (publieur)
    need = Listing(
        listing_id="need-001",
        company_id="acme-logistics",
        type="need",
        title="Consommables emballage carton — Lot 5 000",
        description="Carton ondulé 30x30x20 cm, impression 2 couleurs, livraison Casablanca.",
        sector="Industrie",
        sub_sector="Emballage",
        country="MA",
        city="Casablanca",
        languages=["fr", "en"],
        budget_min_eur=8000.0,
        budget_max_eur=10000.0,
        delivery_days=7,
        quantity=5000,
    )

    # Entreprises candidates
    candidates: list[Company] = [
        Company(
            company_id="c-techmaroc",
            name="TechMaroc SARL",
            sector="Industrie",
            sub_sector="Emballage",
            country="MA", city="Casablanca",
            size_band="51-250",
            languages=["fr", "ar", "en"],
            trust_score=89.0, verified=True, successful_deals=42,
            services=[Listing(
                listing_id="svc-101", company_id="c-techmaroc", type="service",
                title="Carton ondulé imprimé sur mesure",
                description="Production et livraison d'emballages carton.",
                sector="Industrie", sub_sector="Emballage",
                country="MA", city="Casablanca",
                languages=["fr", "en"],
                budget_min_eur=7000.0, budget_max_eur=9500.0,
                delivery_days=5,
            )],
        ),
        Company(
            company_id="c-webpro",
            name="WebPro Agency",
            sector="Services",
            sub_sector="Digital",
            country="TN", city="Tunis",
            size_band="11-50",
            languages=["fr", "en"],
            trust_score=81.0, verified=True, successful_deals=18,
            services=[Listing(
                listing_id="svc-202", company_id="c-webpro", type="service",
                title="Site e-commerce Shopify + logistique",
                description="Agence web full-service incluant intégration Shopify.",
                sector="Services", sub_sector="Digital",
                country="TN", city="Tunis",
                languages=["fr", "en"],
            )],
        ),
        Company(
            company_id="c-ahmed-steel",
            name="Ahmed Steel SARL",
            sector="Industrie",
            sub_sector="Métallurgie",
            country="DZ", city="Alger",
            size_band="1-10",
            languages=["ar"],
            trust_score=58.0, verified=True, successful_deals=3,
            services=[Listing(
                listing_id="svc-303", company_id="c-ahmed-steel", type="service",
                title="Emballage métallique sur mesure",
                description="Caisses et packaging métal pour logistique.",
                sector="Industrie", sub_sector="Emballage",
                country="DZ", city="Alger",
                languages=["ar"],
                budget_min_eur=5000.0, budget_max_eur=14000.0,
                delivery_days=12,
            )],
        ),
        Company(
            company_id="c-trust-unverified",
            name="Nouveau sur Partnexa",
            sector="Industrie", sub_sector="Emballage",
            country="MA", city="Casablanca",
            size_band="1-10", languages=["fr"],
            trust_score=10.0, verified=False, successful_deals=0,
            services=[],
        ),
    ]

    engine = EmbeddingEngine()
    results = smart_match(need, candidates, engine, top_n=5)

    print(f"\nBesoin : {need.title}")
    print(f"Budget : {need.budget_min_eur}–{need.budget_max_eur} EUR   "
          f"Délai : ≤ {need.delivery_days} j   Zone : {need.city} ({need.country})\n")

    for i, r in enumerate(results, start=1):
        print(f"#{i}  {r.company_name:<25} → {r.score:>5.1f}/100")
        print(f"     Raisons : {', '.join(r.reasons) if r.reasons else '—'}")
        print(f"     Badges  : {', '.join(r.badges) if r.badges else '—'}")
        contribs_pct = {
            k: round(v / (WEIGHTS[k] / 100.0), 1)
            for k, v in r.contributions.items()
        }
        print(f"     Détail  : {contribs_pct}\n")


if __name__ == "__main__":
    _demo()
