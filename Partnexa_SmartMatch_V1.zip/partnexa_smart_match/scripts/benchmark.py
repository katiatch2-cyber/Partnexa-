# -*- coding: utf-8 -*-
"""
Benchmark du Smart Match.

Usage :
    python scripts/benchmark.py
    python scripts/benchmark.py --scale 1000 --top-n 20
    python scripts/benchmark.py --scale 10000 --top-n 50  # long
"""
from __future__ import annotations

import argparse
import json
import statistics
import time
from pathlib import Path

# Permet d'exécuter le script depuis n'importe quel répertoire.
ROOT = Path(__file__).resolve().parents[1]
import sys
sys.path.insert(0, str(ROOT))

from smart_match import (
    Listing, Company, EmbeddingEngine, smart_match,
)


def load_sample(needs_fname="sample_needs.json", companies_fname="sample_companies.json"):
    data_dir = ROOT / "data"
    with open(data_dir / needs_fname, encoding="utf-8") as f:
        needs_raw = json.load(f)
    with open(data_dir / companies_fname, encoding="utf-8") as f:
        companies_raw = json.load(f)
    needs = [Listing(**n) for n in needs_raw]
    companies = []
    for c in companies_raw:
        services = [Listing(**s) for s in c.pop("services", [])]
        companies.append(Company(services=services, **c))
    return needs, companies


def synthesize_companies(need: Listing, n: int) -> list[Company]:
    """Génère n entreprises synthétiques pour tester le scaling."""
    base_countries = ["MA", "TN", "DZ", "FR", "AE", "LB", "CI", "SN", "EG", "SA"]
    sectors = ["Industrie", "Services", "Finance", "BTP", "Logistique",
               "Agroalimentaire", "Textile", "Éducation", "Hôtellerie",
               "Santé", "Énergie"]
    out: list[Company] = []
    for i in range(n):
        c_idx = i % len(base_countries)
        s_idx = (i // len(base_countries)) % len(sectors)
        skip_country = (i % 7 == 0)  # 1/7 hors-pays strict
        skip_verified = (i % 11 == 0)  # 1/11 non vérifié
        co = Company(
            company_id=f"syn-{i:05d}",
            name=f"Synthetic Co {i:04d}",
            sector=sectors[s_idx],
            sub_sector="Emballage" if sectors[s_idx] == "Industrie" else "",
            country=("XX" if skip_country else base_countries[c_idx]),
            city="",
            size_band=["1-10", "11-50", "51-250", "250+"][i % 4],
            languages=["fr", "en", "ar"][: (i % 3) + 1],
            trust_score=float(40 + (i % 60)),
            verified=not skip_verified,
            successful_deals=(i % 50),
            services=[Listing(
                listing_id=f"svc-syn-{i:05d}",
                company_id=f"syn-{i:05d}",
                type="service",
                title=f"Synthetic service {i}",
                description="Produit ou service synthétique pour benchmark.",
                sector=sectors[s_idx],
                sub_sector="",
                country="XX" if skip_country else base_countries[c_idx],
                city="",
                languages=["fr", "en"][: (i % 2) + 1],
                budget_min_eur=5000.0,
                budget_max_eur=float(5000 + (i % 9000)),
                delivery_days=1 + (i % 30),
            )],
        )
        out.append(co)
    return out


def run_benchmark(scale: int, top_n: int, repeat: int = 3) -> dict:
    """Exécute le benchmark et retourne un rapport."""
    needs, _ = load_sample()
    need = needs[0]
    candidates = synthesize_companies(need, scale)

    print(f"🔧 Benchmark Smart Match IA")
    print(f"   • Scale        : {scale:,} entreprises")
    print(f"   • Top N        : {top_n}")
    print(f"   • Répétitions  : {repeat}")
    print()

    latencies: list[float] = []
    result_counts: list[int] = []

    engine = EmbeddingEngine()
    for run in range(repeat):
        start = time.perf_counter()
        results = smart_match(need, candidates, engine, top_n=top_n)
        elapsed_ms = (time.perf_counter() - start) * 1000
        latencies.append(elapsed_ms)
        result_counts.append(len(results))
        print(f"   Run {run+1}/{repeat} : {elapsed_ms:>8.2f} ms  →  {len(results)} résultats")

    report = {
        "scale": scale,
        "top_n": top_n,
        "repeats": repeat,
        "latencies_ms": {
            "min": round(min(latencies), 2),
            "max": round(max(latencies), 2),
            "mean": round(statistics.mean(latencies), 2),
            "median": round(statistics.median(latencies), 2),
            "stdev": round(statistics.stdev(latencies), 2) if len(latencies) > 1 else 0.0,
        },
        "results_count_min": min(result_counts),
        "results_count_max": max(result_counts),
    }
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description="Benchmark Partnexa Smart Match")
    parser.add_argument("--scale", type=int, default=100, help="Nb d'entreprises candidates")
    parser.add_argument("--top-n", type=int, default=10, help="Top N résultats")
    parser.add_argument("--repeat", type=int, default=3, help="Nb de répétitions")
    args = parser.parse_args()

    report = run_benchmark(args.scale, args.top_n, args.repeat)

    print()
    print("📊 Rapport :")
    print(json.dumps(report, indent=2, ensure_ascii=False))

    # Objectif cahier § 4 Module E : P95 < 800 ms cold, < 200 ms warm.
    p95_target_cold = 800.0
    status = "✅" if report["latencies_ms"]["max"] <= p95_target_cold else "⚠️"
    print(f"\n{status} P95 cible cold-path = {p95_target_cold} ms (max mesuré = {report['latencies_ms']['max']} ms)")


if __name__ == "__main__":
    main()
