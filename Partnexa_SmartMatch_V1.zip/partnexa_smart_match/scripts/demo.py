# -*- coding: utf-8 -*-
"""
Demo interactive — charge les données JSON et montre 3 matchs complets.

Usage :
    python scripts/demo.py
    python scripts/demo.py --need 3 --top-n 5
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from smart_match import (
    Listing, Company, EmbeddingEngine, smart_match, WEIGHTS,
)


DATA_DIR = ROOT / "data"


def load_json(name: str):
    with open(DATA_DIR / name, encoding="utf-8") as f:
        return json.load(f)


def main() -> None:
    parser = argparse.ArgumentParser(description="Démo Smart Match IA Partnexa")
    parser.add_argument("--need", type=int, default=0, help="Index du besoin (0..9)")
    parser.add_argument("--top-n", type=int, default=5, help="Top N résultats")
    args = parser.parse_args()

    needs_raw = load_json("sample_needs.json")
    companies_raw = load_json("sample_companies.json")

    needs = [Listing(**n) for n in needs_raw]
    companies: list[Company] = []
    for c in companies_raw:
        services = [Listing(**s) for s in c.pop("services", [])]
        companies.append(Company(services=services, **c))

    if not (0 <= args.need < len(needs)):
        print(f"❌ Indice {args.need} hors limites (0..{len(needs)-1}).")
        sys.exit(1)
    need = needs[args.need]

    print("=" * 78)
    print(f"  PARTNEXA — Smart Match IA · Démo")
    print("=" * 78)
    print()
    print(f"  📌 Besoin #{args.need+1}/{len(needs)}  →  {need.title}")
    print(f"     Secteur      : {need.sector} / {need.sub_sector}")
    print(f"     Zone         : {need.city} ({need.country})")
    print(f"     Budget       : {need.budget_min_eur}–{need.budget_max_eur} EUR")
    print(f"     Délai        : ≤ {need.delivery_days} j")
    print(f"     Langues      : {', '.join(need.languages)}")
    print(f"     Entreprises  : {len(companies)} candidates")
    print()

    engine = EmbeddingEngine()
    results = smart_match(need, companies, engine, top_n=args.top_n)

    print(f"  🎯 Top {len(results)} résultats (par score décroissant)")
    print("=" * 78)

    for i, r in enumerate(results, start=1):
        # Barre visuelle (50 chars).
        bar = "█" * int(r.score / 2) + "░" * (50 - int(r.score / 2))
        print()
        print(f"  #{i}  {r.company_name}")
        print(f"      {bar}  {r.score:>5.1f}/100")
        print()
        print(f"      Raisons :")
        for reason in r.reasons:
            print(f"        ✓  {reason}")
        if not r.reasons:
            print(f"        —  (score insuffisant pour recommandation)")
        print(f"      Badges  : {' '.join(r.badges) if r.badges else '—'}")
        print(f"      Contrib. par critère (sur {sum(WEIGHTS.values()):.0f} pts) :")
        max_c = max(r.contributions.values()) if r.contributions else 1
        for k, v in sorted(r.contributions.items(), key=lambda kv: -kv[1]):
            pct = (v / max_c * 30) if max_c else 0
            bar = "▰" * int(pct) + "▱" * (30 - int(pct))
            wt = WEIGHTS[k]
            print(f"       {k:>11} {wt:>5.1f}% │ {bar}  {v:>5.2f}")

    print()
    print("=" * 78)
    print(f"  Pondération totale = {sum(WEIGHTS.values()):.0f} % (cf. cahier § 4 Module E)")
    print("=" * 78)


if __name__ == "__main__":
    main()
