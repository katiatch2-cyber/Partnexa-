# -*- coding: utf-8 -*-
"""Pytest configuration & fixtures partagées."""
from __future__ import annotations

import pytest

# Tentative d'import du module source.
# pytest doit pouvoir s'exécuter même si le module est en chantier.
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


# ──────────────────────────────────────────────────────────────────────────────
# Fixtures : exemples prêts à l'emploi pour tous les tests
# ──────────────────────────────────────────────────────────────────────────────

@pytest.fixture
def sample_need() -> "Listing":  # noqa: F821
    """Un besoin typique (Acme Logistics, Casablanca)."""
    from smart_match import Listing
    return Listing(
        listing_id="need-001",
        company_id="acme-logistics",
        type="need",
        title="Consommables emballage carton — Lot 5 000",
        description="Carton ondulé 30x30x20 cm, impression 2 couleurs, livraison Casablanca.",
        sector="Industrie",
        sub_sector="Emballage",
        country="MA",
        city="Casablanca",
        languages=["fr", "en"],
        budget_min_eur=8000.0,
        budget_max_eur=10000.0,
        delivery_days=7,
        quantity=5000,
    )


@pytest.fixture
def sample_companies() -> list:  # noqa: F821
    """Quatre entreprises candidates : Maroc/Tunis/Algérie + 1 non vérifié."""
    from smart_match import Listing, Company
    return [
        Company(
            company_id="c-techmaroc",
            name="TechMaroc SARL",
            sector="Industrie",
            sub_sector="Emballage",
            country="MA", city="Casablanca",
            size_band="51-250",
            languages=["fr", "ar", "en"],
            trust_score=89.0, verified=True, successful_deals=42,
            services=[Listing(
                listing_id="svc-101", company_id="c-techmaroc", type="service",
                title="Carton ondulé imprimé sur mesure",
                description="Production et livraison d'emballages carton.",
                sector="Industrie", sub_sector="Emballage",
                country="MA", city="Casablanca",
                languages=["fr", "en"],
                budget_min_eur=7000.0, budget_max_eur=9500.0,
                delivery_days=5,
            )],
        ),
        Company(
            company_id="c-webpro",
            name="WebPro Agency",
            sector="Services",
            sub_sector="Digital",
            country="TN", city="Tunis",
            size_band="11-50",
            languages=["fr", "en"],
            trust_score=81.0, verified=True, successful_deals=18,
            services=[Listing(
                listing_id="svc-202", company_id="c-webpro", type="service",
                title="Site e-commerce Shopify + logistique",
                description="Agence web full-service incluant intégration Shopify.",
                sector="Services", sub_sector="Digital",
                country="TN", city="Tunis",
                languages=["fr", "en"],
            )],
        ),
        Company(
            company_id="c-ahmed-steel",
            name="Ahmed Steel SARL",
            sector="Industrie",
            sub_sector="Métallurgie",
            country="DZ", city="Alger",
            size_band="1-10",
            languages=["ar"],
            trust_score=58.0, verified=True, successful_deals=3,
            services=[Listing(
                listing_id="svc-303", company_id="c-ahmed-steel", type="service",
                title="Emballage métallique sur mesure",
                description="Caisses et packaging métal pour logistique.",
                sector="Industrie", sub_sector="Emballage",
                country="DZ", city="Alger",
                languages=["ar"],
                budget_min_eur=5000.0, budget_max_eur=14000.0,
                delivery_days=12,
            )],
        ),
        Company(
            company_id="c-trust-unverified",
            name="Nouveau sur Partnexa",
            sector="Industrie", sub_sector="Emballage",
            country="MA", city="Casablanca",
            size_band="1-10", languages=["fr"],
            trust_score=10.0, verified=False, successful_deals=0,
            services=[],
        ),
    ]
