# -*- coding: utf-8 -*-
"""Tests sur la table de pondérations (intégrité du cahier § 4 Module E)."""
from __future__ import annotations

import pytest

from smart_match import WEIGHTS


class TestWeights:
    """Les pondérations doivent totaliser exactement 100 %."""

    def test_sum_is_exactly_100(self):
        s = sum(WEIGHTS.values())
        assert abs(s - 100.0) < 1e-6, f"Somme = {s}, attendu 100.0"

    def test_all_keys_positive(self):
        for k, v in WEIGHTS.items():
            assert v > 0, f"{k} doit être > 0 (={v})"

    def test_sector_is_dominant(self):
        """25 % — filtre éliminatoire en premier (cahier § 4 Module E)."""
        assert WEIGHTS["sector"] == 25.0

    def test_semantic_is_second(self):
        assert WEIGHTS["semantic"] == 20.0

    def test_exact_nine_criteria(self):
        """Le cahier des charges définit exactement 9 critères."""
        assert len(WEIGHTS) == 9
        expected = {
            "sector", "semantic", "location",
            "budget", "deadline", "language",
            "trust", "size_match", "history",
        }
        assert set(WEIGHTS.keys()) == expected
