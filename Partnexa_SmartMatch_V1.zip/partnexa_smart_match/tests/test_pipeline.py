# -*- coding: utf-8 -*-
"""Tests end-to-end sur la fonction smart_match()."""
from __future__ import annotations

import pytest

from smart_match import EmbeddingEngine, smart_match


@pytest.mark.unit
class TestSmartMatchPipeline:
    """Test du pipeline complet (4 couches)."""

    def test_returns_list(self, sample_need, sample_companies):
        eng = EmbeddingEngine()
        results = smart_match(sample_need, sample_companies, eng)
        assert isinstance(results, list)

    def test_returns_top_n(self, sample_need, sample_companies):
        eng = EmbeddingEngine()
        results = smart_match(sample_need, sample_companies, eng, top_n=2)
        assert len(results) <= 2

    def test_results_sorted_descending(self, sample_need, sample_companies):
        eng = EmbeddingEngine()
        results = smart_match(sample_need, sample_companies, eng)
        scores = [r.score for r in results]
        assert scores == sorted(scores, reverse=True)

    def test_unverified_excluded(self, sample_need, sample_companies):
        eng = EmbeddingEngine()
        results = smart_match(sample_need, sample_companies, eng)
        ids = {r.company_id for r in results}
        assert "c-trust-unverified" not in ids

    def test_company_with_no_services_excluded(self, sample_need):
        from smart_match import Company
        eng = EmbeddingEngine()
        # Compagnie hors-secteur sans services → exclue dès le filtre.
        only = [Company(
            company_id="orphan",
            name="Orphelin", sector="Santé", verified=True,
            services=[],
        )]
        results = smart_match(sample_need, only, eng)
        assert results == []

    def test_empty_input(self, sample_need):
        eng = EmbeddingEngine()
        results = smart_match(sample_need, [], eng)
        assert results == []

    def test_match_result_dataclass_consistency(self, sample_need, sample_companies):
        eng = EmbeddingEngine()
        results = smart_match(sample_need, sample_companies, eng)
        for r in results:
            assert isinstance(r.company_id, str)
            assert isinstance(r.company_name, str)
            assert isinstance(r.score, float)
            assert 0.0 <= r.score <= 100.0
            assert isinstance(r.reasons, list)
            assert isinstance(r.badges, list)
            assert isinstance(r.contributions, dict)
            # Toutes les contributions positives (pas négatifs dans cette V1).
            for v in r.contributions.values():
                assert v >= 0.0

    def test_contributions_sum_approximately_equals_score(self, sample_need, sample_companies):
        """contributions[key] est en points pondérés ; leur somme = final_score."""
        eng = EmbeddingEngine()
        results = smart_match(sample_need, sample_companies, eng)
        for r in results:
            assert abs(sum(r.contributions.values()) - r.score) < 0.5

    def test_techmaroc_in_results(self, sample_need, sample_companies):
        """Le candidat le plus aligné doit ressortir."""
        eng = EmbeddingEngine()
        results = smart_match(sample_need, sample_companies, eng)
        ids = [r.company_id for r in results]
        assert "c-techmaroc" in ids
