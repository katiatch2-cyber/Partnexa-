# -*- coding: utf-8 -*-
"""Tests sur le scoring composite pondéré (couche 3)."""
from __future__ import annotations

import pytest

from smart_match import (
    WEIGHTS, _sigmoid, score_company, Listing, Company,
)


class TestSigmoid:
    def test_sigmoid_zero(self):
        assert _sigmoid(0.0) == 0.5

    def test_sigmoid_positive(self):
        assert _sigmoid(10.0) > 0.99

    def test_sigmoid_negative(self):
        assert _sigmoid(-10.0) < 0.01


def _co(title="Carton", sector="Industrie", sub_sector="Emballage",
        country="MA", city="Casablanca",
        languages=None, budget_min=8000.0, budget_max=9500.0,
        delivery=5, size_band="51-250",
        trust=89.0, verified=True, deals=42):
    from smart_match import Company, Listing
    return Company(
        company_id="c", name=title, sector=sector, sub_sector=sub_sector,
        country=country, city=city, size_band=size_band,
        languages=languages or ["fr", "ar", "en"],
        trust_score=trust, verified=verified, successful_deals=deals,
        services=[Listing(
            listing_id="s", company_id="c", type="service",
            title=title, description="d",
            sector=sector, sub_sector=sub_sector,
            country=country, city=city,
            languages=languages or ["fr"],
            budget_min_eur=budget_min, budget_max_eur=budget_max,
            delivery_days=delivery,
        )],
    )


class TestScoring:
    """Le score doit être dans [0..100] et respecter la pondération."""

    def test_score_in_bounds(self, sample_need):
        c = _co()
        s, contribs, _, _ = score_company(sample_need, c, semantic_score=0.5)
        assert 0.0 <= s <= 100.0

    def test_score_deterministic_company(self, sample_need):
        """Une entreprise parfaitement alignée obtient un score élevé (> 75)."""
        c = _co(
            sector="Industrie", sub_sector="Emballage",
            country="MA", city="Casablanca",
            languages=["fr", "en"], budget_max=9500.0, delivery=5,
            trust=89.0, deals=42,
        )
        s, _, _, _ = score_company(sample_need, c, semantic_score=0.8)
        assert s >= 60.0

    def test_score_low_for_irrelevant_company(self, sample_need):
        """Une entreprise hors-pays et hors-secteur obtient un score bas."""
        c = _co(
            sector="Santé", sub_sector="Clinique",
            country="FR", city="Paris",
            languages=["fr"], budget_max=100000.0, delivery=1,
            trust=10.0, deals=0,
        )
        s, _, _, _ = score_company(sample_need, c, semantic_score=0.0)
        assert s < 30.0

    def test_sector_perfect_match(self, sample_need):
        c = _co(sector="Industrie", sub_sector="Emballage")
        s_perfect, contribs, _, _ = score_company(sample_need, c, 0.0)
        # Quand secteur identique ET sous-secteur identique : 25 pts.
        assert contribs["sector"] == WEIGHTS["sector"]

    def test_sector_wrong(self, sample_need):
        c = _co(sector="Santé", sub_sector="Clinique")
        _, contribs, _, _ = score_company(sample_need, c, 0.0)
        assert contribs["sector"] == 0.0

    def test_budget_perfect_alignment(self, sample_need):
        c = _co(budget_max=9500.0)  # ratio 9500/8000 = 1.1875 → ~ 60
        s_budget, contribs, _, _ = score_company(sample_need, c, 0.0)
        # Ratio 1.1875 > 1.15 → pénalité linéaire.
        assert 0.0 < contribs["budget"] < WEIGHTS["budget"]

    def test_budget_aligned_inside_15pct(self, sample_need):
        c = _co(budget_max=9000.0)  # ratio 9000/8000 = 1.125 ∈ [0.85, 1.15]
        _, contribs, _, _ = score_company(sample_need, c, 0.0)
        assert contribs["budget"] == WEIGHTS["budget"]

    def test_budget_much_higher(self, sample_need):
        c = _co(budget_max=50000.0)  # ratio 50/8 = 6.25 → très pénalisé
        _, contribs, _, _ = score_company(sample_need, c, 0.0)
        assert contribs["budget"] < WEIGHTS["budget"] * 0.3

    def test_language_common(self, sample_need):
        c = _co(languages=["fr", "ar", "en"])
        _, contribs, _, _ = score_company(sample_need, c, 0.0)
        assert contribs["language"] == WEIGHTS["language"]

    def test_language_no_match(self, sample_need):
        c = _co(languages=["de", "ru"])
        _, contribs, _, _ = score_company(sample_need, c, 0.0)
        assert contribs["language"] == 0.0

    def test_trust_score_proportional(self, sample_need):
        s_high, c_high, _, _ = score_company(
            sample_need, _co(trust=89.0), 0.0,
        )
        s_low, c_low, _, _ = score_company(
            sample_need, _co(trust=20.0), 0.0,
        )
        assert c_high["trust"] > c_low["trust"]

    def test_history_sigmoid(self, sample_need):
        """Plus de deals = meilleur score."""
        s_many, c_many, _, _ = score_company(
            sample_need, _co(deals=50), 0.0,
        )
        s_few, c_few, _, _ = score_company(
            sample_need, _co(deals=0), 0.0,
        )
        assert c_many["history"] > c_few["history"]

    def test_city_bonus(self, sample_need):
        """Casablanca vs autre ville MA doit apporter un bonus de localisation."""
        s_match, c_match, _, _ = score_company(
            sample_need, _co(city="Casablanca"), 0.0,
        )
        s_other, c_other, _, _ = score_company(
            sample_need, _co(city="Rabat"), 0.0,
        )
        assert c_match["location"] >= c_other["location"]

    def test_reasons_at_least_three_for_perfect_match(self, sample_need):
        """Cahier § 9.2 : ≥ 3 raisons quand le match est élevé."""
        c = _co(
            sector="Industrie", sub_sector="Emballage",
            country="MA", city="Casablanca",
            languages=["fr", "en"], budget_max=9500.0, delivery=5,
            trust=95.0, deals=30,
        )
        s, _, reasons, _ = score_company(sample_need, c, 0.9)
        assert s >= 60.0
        assert len(reasons) >= 3, f"Attendu ≥3 raisons, obtenu {len(reasons)} : {reasons}"

    def test_reasons_listed_for_low_match(self, sample_need):
        """Pour un match médiocre, moins de raisons (seuil 60)."""
        c = _co(
            sector="Santé", country="FR", city="Paris",
            languages=["de"], budget_max=100.0, delivery=200,
            trust=10.0, deals=0,
        )
        s, _, reasons, _ = score_company(sample_need, c, 0.0)
        # Score faible ⇒ peu/pas de raisons au-dessus du seuil.
        assert len(reasons) <= 1

    def test_3_badges_for_perfect_match(self, sample_need):
        c = _co(
            sector="Industrie", sub_sector="Emballage",
            country="MA", city="Casablanca",
            languages=["fr", "en"], budget_max=9000.0, delivery=5,
            trust=89.0,
        )
        _, _, _, badges = score_company(sample_need, c, 0.8)
        # Logistique OK + Budget OK + Confiance élevée → 3 badges.
        assert "🚚 Logistique OK" in badges
        assert "💰 Budget OK" in badges
        assert "⭐ Confiance élevée" in badges
