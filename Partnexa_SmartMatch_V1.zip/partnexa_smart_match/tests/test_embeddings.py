# -*- coding: utf-8 -*-
"""Tests sur le moteur d'embeddings (couche 2)."""
from __future__ import annotations

import pytest
import numpy as np

from smart_match import EmbeddingEngine, EMBEDDING_DIM


@pytest.mark.unit
class TestEmbeddingEngine:
    """Tests sans charger le modèle lourd (fallback déterministe)."""

    def test_initialization(self):
        eng = EmbeddingEngine()
        # Soit chargé, soit en fallback numpy — les deux sont valides.
        assert eng.model is None or eng.model is not None
        assert eng.index is None
        assert eng.vectors is None
        assert eng.companies == []

    def test_embed_shape(self):
        eng = EmbeddingEngine()
        vecs = eng.embed(["hello world", "carton emballage"])
        assert vecs.shape == (2, EMBEDDING_DIM)
        assert vecs.dtype == np.float32

    def test_embed_l2_normalized(self):
        eng = EmbeddingEngine()
        vecs = eng.embed(["test"])
        n = float(np.linalg.norm(vecs[0]))
        assert abs(n - 1.0) < 1e-5

    def test_embed_deterministic_on_text(self):
        """En mode fallback, même texte → même vecteur."""
        eng = EmbeddingEngine()
        v1 = eng.embed(["carton maroc"])
        v2 = eng.embed(["carton maroc"])
        np.testing.assert_allclose(v1, v2)

    def test_build_index_empty(self):
        eng = EmbeddingEngine()
        eng.build_index([])
        assert eng.index is None
        assert eng.vectors.shape == (0, EMBEDDING_DIM)

    def test_top_k_returns_sorted(self, sample_companies):
        eng = EmbeddingEngine()
        eng.build_index(sample_companies)
        out = eng.top_k("besoin de carton emballage Maroc", k=4)
        assert len(out) > 0
        # Tri décroissant par score ?
        scores = [s for _, s in out]
        assert scores == sorted(scores, reverse=True)

    def test_top_k_respects_limit(self, sample_companies):
        eng = EmbeddingEngine()
        eng.build_index(sample_companies)
        out = eng.top_k("emballage", k=2)
        assert len(out) <= 2
