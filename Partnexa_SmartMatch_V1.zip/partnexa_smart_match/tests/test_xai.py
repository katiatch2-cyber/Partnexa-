# -*- coding: utf-8 -*-
"""Tests sur l'explicabilité (XAI — couche 4)."""
from __future__ import annotations

import pytest

from smart_match import score_company, Listing, Company


def _mk_co(**kw):
    defaults = dict(
        sector="Industrie", sub_sector="Emballage",
        country="MA", city="Casablanca",
        languages=["fr", "en"], budget_min=7000.0, budget_max=9500.0,
        delivery=5, size_band="51-250",
        trust=89.0, deals=42,
    )
    defaults.update(kw)
    return Company(
        company_id="c", name="Test", **defaults,
        services=[Listing(
            listing_id="s", company_id="c", type="service",
            title="t", description="d",
            sector=defaults["sector"], sub_sector=defaults["sub_sector"],
            country=defaults["country"], city=defaults["city"],
            languages=defaults["languages"],
            budget_min_eur=defaults["budget_min"], budget_max_eur=defaults["budget_max"],
            delivery_days=defaults["delivery"],
        )],
    )


class TestExplainability:
    """Garanties XAI du cahier § 9.2 : ≥ 3 raisons lisibles, badges."""

    NEED = Listing(  # besoin par défaut aligné sur _mk_co
        listing_id="n", company_id="acme", type="need",
        title="Carton", description="...",
        sector="Industrie", sub_sector="Emballage",
        country="MA", city="Casablanca",
        languages=["fr", "en"],
        budget_min_eur=8000.0, budget_max_eur=10000.0,
        delivery_days=7,
    )

    def test_match_excellent_has_at_least_three_reasons(self):
        c = _mk_co()
        s, _, reasons, badges = score_company(self.NEED, c, 0.9)
        assert len(reasons) >= 3, reasons

    def test_reasons_are_human_readable_strings(self):
        c = _mk_co()
        _, _, reasons, _ = score_company(self.NEED, c, 0.9)
        for r in reasons:
            assert isinstance(r, str)
            assert len(r) > 5
            # Aucun placeholder vide.
            assert r.strip() != ""

    def test_badges_are_emoji_prefixed(self):
        c = _mk_co()
        _, _, _, badges = score_company(self.NEED, c, 0.9)
        for badge in badges:
            assert badge[0] in ("🚚", "💰", "⭐")

    def test_three_badges_for_perfect_match(self):
        c = _mk_co()
        _, _, _, badges = score_company(self.NEED, c, 0.9)
        assert "🚚 Logistique OK" in badges
        assert "💰 Budget OK" in badges
        assert "⭐ Confiance élevée" in badges

    def test_no_trust_badge_when_low(self):
        c = _mk_co(trust=30.0)
        _, _, _, badges = score_company(self.NEED, c, 0.9)
        assert "⭐ Confiance élevée" not in badges

    def test_no_budget_badge_when_out_of_range(self):
        c = _mk_co(budget_max=100000.0)
        _, _, _, badges = score_company(self.NEED, c, 0.9)
        assert "💰 Budget OK" not in badges

    def test_reasons_top_contribution_order(self):
        """Les raisons les plus fortes apparaissent en premier."""
        c = _mk_co()  # secteur parfait (100) + zone (110) + langues (100)
        _, contribs, reasons, _ = score_company(self.NEED, c, 0.0)
        # Vérifie que sector ET location sont dans le top 3 (par valeur normalisée).
        assert "Secteur identique" in reasons
        assert any("Zone compatible" in r for r in reasons)
