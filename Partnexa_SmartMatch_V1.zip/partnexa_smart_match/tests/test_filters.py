# -*- coding: utf-8 -*-
"""Tests sur les filtres déterministes (couche 1)."""
from __future__ import annotations

import pytest

from smart_match import (
    Company, Listing, deterministic_filters,
)


def _mk(country="MA", sector="Industrie", sub_sector="Emballage",
        verified=True, services=None, name="X", size_band="11-50",
        languages=None, trust=50.0, deals=0):
    return Company(
        company_id=name.lower().replace(" ", "-"),
        name=name, sector=sector, sub_sector=sub_sector,
        country=country, city="", size_band=size_band,
        languages=languages or ["fr"],
        trust_score=trust, verified=verified,
        successful_deals=deals,
        services=services or [],
    )


class TestDeterministicFilters:
    """Filtre éliminatoire — doit être < 5 ms."""

    def test_unverified_company_is_excluded(self, sample_need):
        c = _mk(verified=False, services=[Listing(
            listing_id="s", company_id="x", type="service",
            title="t", description="d", sector="Industrie",
            sub_sector="Emballage",
        )])
        assert deterministic_filters(sample_need, [c]) == []

    def test_country_mismatch_is_excluded(self, sample_need):
        c = _mk(country="US", verified=True, services=[Listing(
            listing_id="s", company_id="x", type="service",
            title="t", description="d", sector="Industrie",
            sub_sector="Emballage",
        )])
        assert deterministic_filters(sample_need, [c]) == []

    def test_country_match_keeps_company(self, sample_need):
        c = _mk(country="MA", verified=True, services=[Listing(
            listing_id="s", company_id="x", type="service",
            title="t", description="d", sector="Industrie",
            sub_sector="Emballage",
        )])
        out = deterministic_filters(sample_need, [c])
        assert len(out) == 1
        assert out[0].company_id == c.company_id

    def test_company_with_matching_sector_kept_even_without_services(self, sample_need):
        c = _mk(country="MA", sector="Industrie", verified=True, services=[])
        out = deterministic_filters(sample_need, [c])
        assert out == [c]

    def test_company_with_different_sector_and_no_services_excluded(self, sample_need):
        c = _mk(country="MA", sector="Services", verified=True, services=[])
        # sample_need est dans "Industrie", donc secteur différent ET pas de services.
        assert deterministic_filters(sample_need, [c]) == []

    def test_empty_input(self, sample_need):
        assert deterministic_filters(sample_need, []) == []

    def test_mixed_batch(self, sample_need, sample_companies):
        # 4 candidates : 2 gardées (Maroc vérifiés), 2 exclues (Tunis pays,
        # Algérie pays, ou non vérifié).
        kept = deterministic_filters(sample_need, sample_companies)
        # Selon l'implémentation `country!="MA"` strict :
        # - TechMaroc MA ✓ vérifié ✓ → gardé
        # - WebPro TN ✗ → exclu
        # - Ahmed Steel DZ ✗ → exclu
        # - Nouveau MA ✓ non vérifié ✗ → exclu
        ids = {c.company_id for c in kept}
        assert ids == {"c-techmaroc"}
