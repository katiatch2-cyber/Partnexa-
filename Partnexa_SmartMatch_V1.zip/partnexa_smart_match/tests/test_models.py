# -*- coding: utf-8 -*-
"""Tests sur les dataclasses (modèles de données)."""
from __future__ import annotations

import pytest

from smart_match import Listing, Company, MatchResult, MatchFeedback


class TestDataclasses:
    """Instanciation, valeurs par défaut, méthodes utilitaires."""

    def test_listing_defaults(self):
        lst = Listing(
            listing_id="x",
            company_id="y",
            type="need",
            title="t",
            description="d",
            sector="Industrie",
        )
        assert lst.sub_sector == ""
        assert lst.country == ""
        assert lst.budget_min_eur is None
        assert lst.languages == []

    def test_listing_to_text(self):
        lst = Listing(
            listing_id="x", company_id="y", type="need",
            title="Cartons", description="10k unités",
            sector="Industrie", sub_sector="Emballage",
            country="MA", city="Casablanca",
            languages=["fr", "en"],
        )
        text = lst.to_text()
        assert "Cartons" in text
        assert "Industrie" in text
        assert "Casablanca" in text
        assert "fr,en" in text

    def test_company_defaults(self):
        c = Company(
            company_id="c",
            name="X",
            sector="Industrie",
        )
        assert c.trust_score == 0.0
        assert c.verified is False
        assert c.successful_deals == 0
        assert c.services == []

    def test_match_result_defaults(self):
        r = MatchResult(company_id="c", company_name="X", score=50.0)
        assert r.reasons == []
        assert r.badges == []
        assert r.contributions == {}

    def test_match_feedback_db_row(self):
        fb = MatchFeedback(
            need_id="n-1", company_id="c-1",
            signal="positive", comment="Top!",
        )
        row = fb.to_db_row()
        assert row == {
            "need_id": "n-1",
            "company_id": "c-1",
            "signal": "positive",
            "comment": "Top!",
        }

    @pytest.mark.parametrize("signal", ["positive", "negative", "neutral"])
    def test_match_feedback_signals(self, signal):
        fb = MatchFeedback(need_id="n", company_id="c", signal=signal)
        assert fb.signal == signal
