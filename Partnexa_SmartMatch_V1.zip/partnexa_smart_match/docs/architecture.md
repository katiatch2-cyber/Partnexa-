# Architecture du Smart Match IA

## Vue d'ensemble

```
   ┌──────────────┐         ┌─────────────────────────────────────────────┐
   │   BESOIN     │────────►│                                             │
   │ (Listing)    │         │              SMART MATCH PIPELINE           │
   └──────────────┘         │                                             │
                            │  COUCHE 1 — FILTRES DÉTERMINISTES           │
   ┌──────────────┐         │  ┌──────────────────────────────────────┐   │
   │ ENTREPRISES  │────────►│  │ • Pays, vérification, secteur        │   │
   │ (Company)    │         │  │ • < 5 ms — élimine 95 % du bruit     │   │
   │ + Services   │         │  └──────────────────────────────────────┘   │
   └──────────────┘         │                       │                     │
                            │                       ▼                     │
                            │  COUCHE 2 — EMBEDDINGS MULTILINGUES         │
                            │  ┌──────────────────────────────────────┐   │
                            │  │ • bge-m3 (BAAI) 1024-d, FR/AR/EN    │   │
                            │  │ • FAISS IndexFlatIP                  │   │
                            │  │ • K-NN cosine top-200                │   │
                            │  └──────────────────────────────────────┘   │
                            │                       │                     │
                            │                       ▼                     │
                            │  COUCHE 3 — SCORING COMPOSITE PONDÉRÉ      │
                            │  ┌──────────────────────────────────────┐   │
                            │  │ • 9 critères × poids (somme = 100%)  │   │
                            │  │ • Score final ∈ [0..100]             │   │
                            │  └──────────────────────────────────────┘   │
                            │                       │                     │
                            │                       ▼                     │
                            │  COUCHE 4 — EXPLICABILITÉ (XAI)            │
                            │  ┌──────────────────────────────────────┐   │
                            │  │ • Top 3 raisons lisibles ≥ 60        │   │
                            │  │ • Badges logistiques/budget/confiance│   │
                            │  │ • Carte de contributions              │   │
                            │  └──────────────────────────────────────┘   │
                            │                       │                     │
                            │                       ▼                     │
                            │  ┌──────────────────────────────────────┐   │
                            │  │ TOP-N MatchResults (tri descendant)  │   │
                            │  │ • score, reasons, badges, contribs    │   │
                            │  └──────────────────────────────────────┘   │
                            └─────────────────────────────────────────────┘
```

## Critères pondérés (cahier § 4 Module E)

| # | Critère | Poids | Implémentation | Tolérance |
|---:|---|---:|---|---|
| 1 | Secteur | **25** | exact match → 100, sous-secteur → 50 | strict |
| 2 | Sémantique | **20** | cosine embeddings multilingues 0..1 | continue |
| 3 | Localisation | **15** | pays match 100, voisinage MENA 60, +10 ville exacte | escalier |
| 4 | Budget | **12** | ratio svc.max / need.min ∈ [0.85, 1.15] → 100 | triangulaire |
| 5 | Délai | **10** | ratio svc.days / need.days → 100, sinon décroît | continu |
| 6 | Langues | **8** | 1+ commune → 100 | booléen |
| 7 | Trust | **5** | trust_score ∈ [0..100] | continu |
| 8 | Taille | **3** | PME→PME fav., grand→grand fav. | heuristique |
| 9 | Historique | **2** | sigmoid((deals − 5) / 5) | continu |

## Explicabilité (cahier § 9.2)

- **Seuil XAI** : contribution_normalisée ≥ 60 → retenue comme raison.
- **Top 3 raisons** triées par contribution décroissante.
- **Badges** déclenchés sur contributions ≥ 80 (3 possibles).
- **Carte complète** `contributions[key]` toujours retournée (transparence totale pour UI "Pourquoi pas 95 % ?").

## Mode dégradé

En l'absence de `sentence-transformers` ou `faiss`, le pipeline reste fonctionnel :
- Embeddings = vecteurs pseudo-aléatoires reproductibles (`hash` du texte) — utiles pour CI/tests mais sémantiquement vides.
- K-NN = produit matriciel numpy — équivalent à l'index FAISS interne.

Le scoring et la XAI fonctionnent identiquement. Aucune différence visible côté API.

## Performance cible (cahier § 4 NFR)

| Métrique | Cible | Conditions |
|---|---:|---|
| Latence P95 cold path | < 800 ms | 1 000 entreprises |
| Latence P95 warm path | < 200 ms | cache Redis hit |
| Throughput | ≥ 10 req/s | 1 instance, GPU off |
| Mémoire | < 2 Go | par instance (modèle hors RAM) |

## V1.1 — Ré-entraînement LambdaMART

Les retours 👍 / 👎 sont stockés via `MatchFeedback.to_db_row()` puis batchés en table `match_feedback`. Mensuellement, un job `LambdaMART` ré-apprend la pondération :

```
loss = -∑ log(P(match_i = positive | x_i, w))
w_new = argmin_w loss + λ ||w − w_default||
```

L'A/B test permanent (10 % trafic) valide la nouvelle pondération avant bascule.
