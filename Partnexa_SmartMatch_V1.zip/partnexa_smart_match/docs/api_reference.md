# Référence API publique (V1)

Ce module expose une **API procédurale pure Python** (pas de serveur HTTP en V1 — prévu FastAPI en V1.1).

## Types principaux

### `Listing`

Représente un **besoin** (`type="need"`) ou un **service** (`type="service"`).

```python
@dataclass
class Listing:
    listing_id: str
    company_id: str
    type: Literal["need", "service"]
    title: str
    description: str
    sector: str
    sub_sector: str = ""
    country: str = ""
    city: str = ""
    languages: list[str] = []
    budget_min_eur: float | None = None
    budget_max_eur: float | None = None
    delivery_days: int | None = None
    quantity: float | None = None
```

**Méthodes**

| Méthode | Signature | Description |
|---|---|---|
| `to_text()` | `() -> str` | Texte canonique pour vectorisation. |

### `Company`

Représente une entreprise (avec son catalogue de services).

```python
@dataclass
class Company:
    company_id: str
    name: str
    sector: str
    sub_sector: str = ""
    country: str = ""
    city: str = ""
    size_band: str = ""
    languages: list[str] = []
    trust_score: float = 0.0
    verified: bool = False
    successful_deals: int = 0
    services: list[Listing] = []
```

### `MatchResult`

Résultat d'un match.

```python
@dataclass
class MatchResult:
    company_id: str
    company_name: str
    score: float            # 0..100
    reasons: list[str]      # ≥ 3 raisons lisibles
    badges: list[str]       # badges visuels
    contributions: dict[str, float]  # {critère: pts pondérés}
```

## Fonctions principales

### `smart_match(need, candidates, engine, top_n=10)`

Pipeline complet en 4 étapes.

```python
from smart_match import smart_match, EmbeddingEngine, Listing, Company

results = smart_match(
    need,
    candidate_companies,
    engine,                # instance d'EmbeddingEngine
    top_n=10,
) -> list[MatchResult]
```

### `score_company(need, company, semantic_score)`

Calcule le score composite d'une entreprise candidate.

```python
score, contributions, reasons, badges = score_company(need, company, 0.5)
# score: float ∈ [0..100]
# contributions: {key: pts pondérés}
# reasons: list[str]
# badges: list[str]
```

### `deterministic_filters(need, candidates)`

Couche 1 — filtre éliminatoire rapide.

```python
candidates_filtred = deterministic_filters(need, candidates) -> list[Company]
```

### `EmbeddingEngine(class)`

Gestionnaire d'embeddings + index vectoriel.

```python
engine = EmbeddingEngine()                       # bge-m3 par défaut
engine = EmbeddingEngine("intfloat/multilingual-e5-large")  # autre modèle

engine.build_index(companies)                    # indexe in-memory
results = engine.top_k(query_text, k=200)        # K-NN cosine
```

### `MatchFeedback(need_id, company_id, signal, comment="")`

Stockage des feedbacks utilisateurs (👍/👎).

```python
fb = MatchFeedback("need-001", "c-techmaroc", "positive", "Top!")
db_row = fb.to_db_row()  # prêt pour INSERT SQL
```

## Exemple end-to-end

```python
from pathlib import Path
import json
from smart_match import (
    Listing, Company, EmbeddingEngine, smart_match,
)

DATA = Path("data")

needs = [Listing(**n) for n in json.loads((DATA / "sample_needs.json").read_text())]

companies = []
for c in json.loads((DATA / "sample_companies.json").read_text()):
    services = [Listing(**s) for s in c.pop("services", [])]
    companies.append(Company(services=services, **c))

engine = EmbeddingEngine()
results = smart_match(needs[0], companies, engine, top_n=5)

for r in results:
    print(f"{r.company_name:<25} {r.score}/100 — {len(r.reasons)} raisons")
```

## Constantes exportées

```python
EMBEDDING_MODEL = "BAAI/bge-m3"
EMBEDDING_DIM = 1024
WEIGHTS = {
    "sector": 25.0, "semantic": 20.0, "location": 15.0,
    "budget": 12.0, "deadline": 10.0, "language": 8.0,
    "trust": 5.0, "size_match": 3.0, "history": 2.0,
}
```

## Notes de production

- En prod, charger `config/production.yaml` et configurer `EMBEDDING_DEVICE=cuda`.
- Brancher Redis sur le warm path : `cache_key = hash(need_id + version_poids)`.
- Brancher Kafka sur `MatchFeedback.to_db_row()` : topic `partnexa.match.feedback`.
- L'API HTTP FastAPI est prévue en V1.1 — voir `docs/architecture.md`.
