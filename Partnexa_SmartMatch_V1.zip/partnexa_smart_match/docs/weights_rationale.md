# Justification des pondérations (V1)

Cette note explique le choix de chaque poids du score composite, conforme au cahier des charges § 4 Module E.

## Méthode générale

| Critère | Poids | Principe de fixation |
|---|---:|---|
| Secteur | **25** | Filtre éliminatoire en premier. Si deux entreprises ne sont pas du même secteur, la pertinence business est trop faible. |
| Sémantique | **20** | Le besoin est souvent mal formulé ; les embeddings comprennent l'_intention_ même quand les mots divergent. |
| Localisation | **15** | Le coût logistique et la juridiction sont décisifs. La V1 applique un matching strict sur le pays, maistolère un voisinage MENA (MA/TN/DZ). |
| Budget | **12** | Un écart de ±15 % reste acceptable ; au-delà, le deal est inutile. |
| Délai | **10** | L'urgence opérationnelle est forte mais modulable. |
| Langues | **8** | Capacité d'échange = nécessité absolue (note haute mais pas éliminatoire en V1 — un traducteur externe peut fonctionner). |
| Trust | **5** | Pondération volontairement basse pour ne pas pénaliser injustement les nouveaux inscrits. |
| Taille | **3** | Heuristique : « gros fournisseur pour gros client, petit fournisseur pour petit client ». |
| Historique | **2** | Renforcement continu — pas de bootstrapping value pour un newcomer. |

**Somme = 100 %** (contrainte algorithmique, validée par `tests/test_weights.py`).

## Pourquoi pas plus haut/courant sur certains critères ?

- **Secteur (25 %)** : testons-nous à 35 % ? Trop éliminatoire : une PME emballage qui cherche aussi du conseil logistique transverse ne trouverait rien. 25 % reste discriminant sans être rigide.
- **Sémantique (20 %)** : sur-peser reviendrait à nicher le scoring dans le modèle d'embedding — ce qu'on veut éviter pour la lisibilité et l'audit (RGPD, XAI).
- **Trust (5 %)** : un newcomer avec un KYC validé doit quand même apparaître dans les résultats — au prix d'un tri moindre.

## Plan d'expérimentation V1.1

Après 90 jours de données de feedback (👍/👎), on lancera un job LambdaMART qui ré-apprendra les poids. Hypothèse attendue :
- **semantic ↑ (20 → 22)** : le scoring sémantique gagne en fiabilité.
- **trust ↑ (5 → 7)** : les nouveaux partenaires sans historique de deals sont restés longtemps sans contact → davantage pondérer le KYC.
- **sector ↓ (25 → 20)** : sur la base 1ʳᵉ, on découvre des matchs transversaux pertinents (ex : imprimeur + logisticien).

Cette mise à jour sera déployée via `config/weights.yaml` et A/B-testée à 10 % du trafic.

## XAI et seuils

- **Seuil "raison" = 60** : contribution normalisée ≥ 60 / 100 pour le critère.
- **Seuil "badge" = 80** : même chose mais plus strict (joue le rôle d'un "highlight").
- Ces seuils sont Figure 1 des arbitrages UX produit — modifiables en V1.1 sans toucher au scoring.
