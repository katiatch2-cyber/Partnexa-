# 🧠 Partnexa — Smart Match IA · V1

> **Module E du Cahier des Charges Partnexa V1.0**
> *Connecter les bonnes entreprises, au bon moment, grâce à l'IA.*

Moteur de recommandation **explicable** qui apparie les **besoins** publiés par les entreprises avec les **entreprises candidates** (et leurs services), en attribuant à chacune un score composite (0–100), des raisons lisibles, et des badges visuels.

---

## ✨ Caractéristiques

- **Architecture 4 couches** : filtres déterministes → embeddings multilingues (bge-m3, 1024-d) → scoring composite pondéré → explicabilité XAI (≥ 3 raisons + badges).
- **9 critères pondérés** totalisant 100 % (secteur, sémantique, localisation, budget, délai, langue, trust, taille, historique).
- **Mode dégradé** : fonctionne sans GPU ni modèle préchargé (fallback déterministe reproductible).
- **XAI natif** : chaque match expose contributions détaillées + 3 raisons principales + badges.
- **Pipeline feedback** : dataclass `MatchFeedback` prête pour ré-entraînement mensuel LambdaMART.

---

## 📂 Architecture du projet

```
partnexa_smart_match/
├── smart_match.py              ← Pipeline principal (580 lignes)
├── requirements.txt            ← Dépendances prod (FastAPI + FAISS + sentence-transformers)
├── requirements-min.txt        ← Dépendances minimales (numpy seul, pour CI léger)
├── README.md                   ← Ce fichier
├── .gitignore
├── .env.example                ← Variables d'environnement (template)
├── pytest.ini                  ← Configuration pytest
├── pyproject.toml              ← Métadonnées projet
├── Dockerfile                  ← Image de production (CPU)
├── LICENSE                     ← Licence MIT
│
├── tests/                      ← Suite de tests unitaires
│   ├── __init__.py
│   ├── conftest.py             ← Fixtures pytest
│   ├── test_models.py          ← Tests dataclasses
│   ├── test_filters.py         ← Tests filtres déterministes
│   ├── test_scoring.py         ← Tests scoring composite
│   ├── test_embeddings.py      ← Tests EmbeddingEngine
│   ├── test_pipeline.py        ← Tests smart_match() end-to-end
│   ├── test_xai.py             ← Tests explicabilité (raisons + badges)
│   └── test_weights.py         ← Tests pondérations (somme = 100%)
│
├── data/                       ← Jeux de données de démonstration
│   ├── sample_needs.json       ← 10 besoins exemples
│   ├── sample_companies.json   ← 15 entreprises candidates
│   └── README.md
│
├── scripts/                    ← Scripts utilitaires
│   ├── demo.py                 ← Démonstration interactive (USAGE)
│   └── benchmark.py            ← Benchmarks performance
│
├── docs/                       ← Documentation technique
│   ├── architecture.md         ← Diagrammes + détails 4 couches
│   ├── weights_rationale.md    ← Justification des pondérations
│   └── api_reference.md        ← Référence API publique
│
├── config/                     ← Configurations par environnement
│   ├── development.yaml
│   ├── production.yaml
│   └── weights.yaml            ← Pondérations surchargeables (12-factor)
│
└── .github/
    └── workflows/
        └── ci.yml              ← Tests automatisés (GitHub Actions)
```

---

## 🚀 Démarrage rapide

### 1. Installation

```bash
# Cloner / extraire le projet, puis :
cd partnexa_smart_match

# Créer un environnement virtuel
python3 -m venv .venv
source .venv/bin/activate           # Linux / macOS
# .venv\Scripts\activate            # Windows

# Installer les dépendances
pip install -r requirements.txt    # Complet (prod)
# OU
pip install -r requirements-min.txt # Minimal (CI léger)
```

### 2. Lancer la démo

```bash
python smart_match.py
```

Sortie attendue (TechMaroc arrive en tête avec **75.4/100**) :

```
========================================================================
PARTNEXA — Smart Match IA · Démo
========================================================================

Besoin : Consommables emballage carton — Lot 5 000
Budget : 8000.0–10000.0 EUR   Délai : ≤ 7 j   Zone : Casablanca (MA)

#1  TechMaroc SARL            →  75.4/100
     Raisons : Secteur identique, Zone compatible (Casablanca), Langue commune : en,fr
     Badges  : 🚚 Logistique OK, 💰 Budget OK, ⭐ Confiance élevée
     Détail  : {'sector': 100.0, 'semantic': 0.0, 'location': 100.0, ...}

#2  WebPro Agency             →  41.2/100
     ...
```

### 3. Lancer les tests

```bash
pytest                              # Suite complète
pytest --cov=smart_match            # Avec couverture
pytest -v tests/test_scoring.py     # Un fichier précis
pytest -k "test_score"              # Filtrer par nom
```

### 4. Utilisation programmatique

```python
from smart_match import (
    Listing, Company, EmbeddingEngine, smart_match
)

need = Listing(
    listing_id="need-001",
    company_id="acme-logistics",
    type="need",
    title="Consommables emballage carton",
    description="Carton ondulé 30x30x20 cm, livraison Casablanca.",
    sector="Industrie", sub_sector="Emballage",
    country="MA", city="Casablanca",
    languages=["fr", "en"],
    budget_min_eur=8000.0, budget_max_eur=10000.0,
    delivery_days=7,
)

candidates = [
    Company(
        company_id="c-techmaroc",
        name="TechMaroc SARL",
        sector="Industrie", sub_sector="Emballage",
        country="MA", city="Casablanca",
        size_band="51-250",
        languages=["fr", "ar", "en"],
        trust_score=89.0, verified=True, successful_deals=42,
        services=[...],
    ),
    # ... plus d'entreprises
]

engine = EmbeddingEngine()
results = smart_match(need, candidates, engine, top_n=10)

for r in results:
    print(f"{r.company_name}: {r.score}/100")
    print(f"  Raisons: {r.reasons}")
    print(f"  Badges: {r.badges}")
```

---

## 🧪 Architecture algorithmique (4 couches)

| Couche | Rôle | Implémentation |
|---|---|---|
| **1. Filtres déterministes** | Élimination rapide (< 5 ms) : pays, vérification, secteur | `deterministic_filters()` |
| **2. Embeddings multilingues** | Similarité sémantique FR/AR/EN | `EmbeddingEngine` (bge-m3, 1024-d) |
| **3. Scoring composite pondéré** | Score 0–100 = Σ (critère × poids) | `score_company()` |
| **4. Explicabilité XAI** | ≥ 3 raisons lisibles + badges | Branche finale de `score_company()` |

### Pondérations V1 (cahier § 4 Module E)

| Critère | Poids | Justification |
|---|---:|---|
| Secteur | **25 %** | Filtre éliminatoire en premier |
| Sémantique | **20 %** | Compréhension du besoin même mal formulé |
| Localisation | **15 %** | Logistique & juridiction |
| Budget (±15 %) | **12 %** | Filtrage économique |
| Délai | **10 %** | Urgence opérationnelle |
| Langues | **8 %** | Capacité d'échange |
| Trust Score | **5 %** | Réduction de risque |
| Taille d'entreprise | **3 %** | Capacité à livrer |
| Historique | **2 %** | Réinforcement continu |
| **TOTAL** | **100 %** | — |

---

## 🔧 Configuration (12-factor)

Les pondérations sont surchargeables via `config/weights.yaml` puis chargées par `config.loader`. Aucune valeur en dur dans `score_company()`.

Voir [`docs/weights_rationale.md`](docs/weights_rationale.md) pour la justification méthodologique.

---

## 🌐 Multilingue (vrai support FR / AR / EN)

Le modèle `bge-m3` est nativement multilingue. La fonction `to_text()` concatène titre + description + secteur + zone + langues et est encodée telle quelle — pas de traduction amont.

L'explicabilité est générée **dans la langue de l'utilisateur** via le paramètre `locale="fr"|"ar"|"en"` (extension V1.1).

---

## 🤝 Contribution

1. Installer le hook pre-commit (`pre-commit install`)
2. Lancer `ruff check . && ruff format .`
3. Vérifier que la couverture reste ≥ 80 %
4. Tester localement `pytest -v`
5. PR avec description détaillée

---

## 📜 Licence

MIT — voir [`LICENSE`](LICENSE).

---

## 📞 Contact

Partnexa — *Connecter les bonnes entreprises, au bon moment, grâce à l'IA.*
Equipe Partnexa · Novembre 2025 · v1.0
