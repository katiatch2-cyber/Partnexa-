# 📂 Données d'exemple Partnexa V1

## Fichiers

| Fichier | Description |
|---|---|
| `sample_needs.json` | 10 besoins publiés par des entreprises (Acme, Startup Tech TN, Hôtel Marrakech, etc.) |
| `sample_companies.json` | 15 entreprises candidates (vérifiées, multi-pays, multi-sectorielles) |

## Chargement depuis Python

```python
import json
from pathlib import Path
from smart_match import Listing, Company, EmbeddingEngine, smart_match

DATA = Path(__file__).parent / "data"

def load_json(fname):
    with open(DATA / fname, encoding="utf-8") as f:
        return json.load(f)

needs = [Listing(**n) for n in load_json("sample_needs.json")]
companies = []
for c in load_json("sample_companies.json"):
    services = [Listing(**s) for s in c.pop("services", [])]
    companies.append(Company(services=services, **c))

# Exemple : matcher le 1ᵉʳ besoin contre toutes les entreprises.
results = smart_match(needs[0], companies, EmbeddingEngine(), top_n=5)
for r in results:
    print(f"{r.company_name:<25} {r.score}/100")
```

## Couverture géographique

- 🇲🇦 Maroc (Casablanca, Marrakech, Tanger)
- 🇹🇳 Tunisie (Tunis)
- 🇩🇿 Algérie (Alger)
- 🇫🇷 France (Paris, Lyon)
- 🇦🇪 Émirats (Dubai, Abu Dhabi)
- 🇱🇧 Liban (Beyrouth)
- 🇨🇮 Côte d'Ivoire (Abidjan)
- 🇸🇳 Sénégal (Dakar)

Représente la cible Phase 1 du cahier des charges.
